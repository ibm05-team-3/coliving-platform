package com.coliving.platform.contract.dto;

import java.time.LocalDate;

public record ContractDocumentCreateRequest(
        Long applicationId,
        String language,        // "ko" / "en" → 문서 서비스가 양식 선택
        String applicantName,
        String applicantPhone,
        String applicantAddress,
        String buildingName,
        String roomName,
        String roomType,
        LocalDate moveInDate,
        LocalDate moveOutDate,
        Integer months,
        Long monthlyFee,
        Long deposit
) {}


